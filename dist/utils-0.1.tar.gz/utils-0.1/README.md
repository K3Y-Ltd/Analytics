# ACROSS - Analytics

This repository contains the Analytics tools developed for the ACROSS project.

Each directory includes comprehensive instructions essential for deploying each tool.

### Tools provided as-a-service

1) Training
2) Inference
3) Data Receptor
4) Adversarial Generator
5) Adversarial Discriminator
6) Resilience Verificator
